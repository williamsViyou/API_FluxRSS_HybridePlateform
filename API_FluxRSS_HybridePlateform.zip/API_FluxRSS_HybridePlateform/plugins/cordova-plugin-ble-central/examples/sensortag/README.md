## SensorTag

Interact with the [TI SensorTag](http://www.ti.com/tool/cc2541dk-sensor)

 * Read Button Presses
 * Read Accelerometer Data

Hardware

 * [TI SensorTag](http://www.ti.com/tool/cc2541dk-sensor)

Install

    $ cordova platform add android ios
    $ cordova plugin add cordova-plugin-ble-central
    $ cordova run
    
