# RoboSmart

Control a [SmartBotics](http://www.smartbotics.com/) RoboSmart Lightbulb from your phone.

Hardware

    * [RoboSmart Lightbulb](http://www.smartbotics.com/#!where-to-buy/c1kf9)
    
Install

    $ cordova platform add android ios
    $ cordova plugin add cordova-plugin-ble-central
    $ cordova run
    

